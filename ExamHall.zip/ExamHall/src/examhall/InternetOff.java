/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examhall;

/**
 *
 * @author Mehedi Hasan
 */
public class InternetOff {
	public static void NetOff() throws Exception
	{
		Process process = java.lang.Runtime.getRuntime().exec("cmd /c ipconfig /release");
		int x = process.waitFor();
		if (x == 0) {
			System.out.println("Network Off Successful");
		}
		else {
			System.out.println("Error");
		}
	}
        public static void NetON() throws Exception
	{
		Process process = java.lang.Runtime.getRuntime().exec("cmd /c ipconfig /renew");
		int x = process.waitFor();
		if (x == 0) {
			System.out.println("Network On Successful");
		}
		else {
			System.out.println("Error");
		}
	}
        
    public static void CheckNetConnection() throws Exception
    {
        Process process = java.lang.Runtime.getRuntime().exec("ping www.google.com");
        int x = process.waitFor();
        if (x == 0) {
            System.out.println("Connection Successful, "
                               + "Output was " + x);
        }
        else {
            System.out.println("Internet Not Connected, "
                               + "Output was " + x);
        }
    }
}
